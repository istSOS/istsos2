# istSOS Istituto Scienze della Terra Sensor Observation Service
# Copyright (C) 2010 Massimiliano Cannata
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA


import psycopg2 # @TODO the right library
import psycopg2.extras
import os

import sosConfig
from istSOS import sosDatabase
from istSOS import sosException
import mx.DateTime.ISO
import isodate as iso

def BuildobservedPropertyList(pgdb,offering):
    list=[]
    sql = "SELECT distinct(name_opr) as nopr FROM %s.procedures, %s.proc_obs p," %(sosConfig.schema,sosConfig.schema)
    sql += " %s.observed_properties, %s.off_proc o, %s.offerings" %(sosConfig.schema,sosConfig.schema,sosConfig.schema)
    sql += " WHERE id_opr_fk=id_opr AND p.id_prc_fk=id_prc AND o.id_prc_fk=id_prc AND id_off=id_off_fk"
    sql += " AND name_off='%s' ORDER BY nopr" %(offering)
    rows=pgdb.select(sql)
    for row in rows:
        list.append(row["nopr"])
    return list

def BuildfeatureOfInterestList(pgdb,offering):
    list=[]
    sql = "SELECT distinct(name_foi) as nfoi FROM %s.foi, %s.procedures " %(sosConfig.schema,sosConfig.schema)
    sql += " , %s.off_proc, %s.offerings" %(sosConfig.schema,sosConfig.schema)
    sql += " WHERE id_foi=id_foi_fk AND id_prc_fk=id_prc"
    sql += " AND id_off=id_off_fk AND name_off='%s' ORDER BY nfoi"  %(offering)
  
    try:
        rows=pgdb.select(sql)
    except:
        raise sosException.SOSException(1,"sql: %s" %(sql))
    for row in rows:
        list.append(row["nfoi"])
    return list

    
def BuildProcedureList(pgdb,offering):
    list=[]
    sql = "SELECT name_prc FROM %s.procedures, %s.off_proc, %s.offerings"  %(sosConfig.schema,sosConfig.schema,sosConfig.schema)
    sql += " WHERE id_prc=id_prc_fk AND id_off=id_off_fk AND name_off='%s'" %(offering)
    sql += " ORDER BY name_prc"
    rows=pgdb.select(sql)
    for row in rows:
        list.append(row["name_prc"])    
    return list

def BuildOfferingList(pgdb):
    list=[]
    sql = "SELECT distinct(name_off) FROM %s.procedures,%s.off_proc,%s.offerings" %(sosConfig.schema,sosConfig.schema,sosConfig.schema)
    sql += " WHERE  id_prc=id_prc_o_fk AND id_off_fk=id_off ORDER BY name_off"
    rows=pgdb.select(sql)
    for row in rows:
        list.append(row["name_off"])


class offInfo:
    def __init__(self,off_name,pgdb):
        sql = "SELECT name_off, desc_off FROM %s.offerings WHERE name_off='%s'" %(sosConfig.schema,off_name)
        try:
            off = pgdb.select(sql)[0]
            self.name=off["name_off"]
            self.desc=off["desc_off"]
        except:
            raise sosException.SOSException(2,"Parameter \"offering\" sent with invalid value: %s"%(off_name))
        
class observation:
    def __init__(self):
        self.procedure=None
        self.id_prc=None
        self.procedureType=None
        self.samplingTime=None
        self.refsys = None
        self.timeResUnit=None
        self.timeResVal=None
        self.observedProperty=None
        self.opr_urn=None
        self.uom=None
        self.featureOfInterest=None
        self.foi_urn=None
        self.foiGml = None
        self.dataType=None
        self.timedef = None
        self.qualitydef = None
        self.data=[]
        
class observations:
    def __init__(self,filter,pgdb):
        self.offInfo = offInfo(filter.offering,pgdb)
        self.refsys = sosConfig.urn["refsystem"] + filter.srsName
        
        #CHECK FILTER VALIDITY
        #=========================================
        if filter.procedure:
            pl = BuildProcedureList(pgdb,filter.offering)
            for p in filter.procedure:
                if not p in pl:
                    raise sosException.SOSException(2,"Parameter \"procedure\" sent with invalid value: %s -  available options for offering \"%s\": %s"%(p,filter.offering,pl))
        
        if filter.featureOfInterest:
            fl = BuildfeatureOfInterestList(pgdb,filter.offering)
            if not filter.featureOfInterest in fl:
                raise sosException.SOSException(2,"Parameter \"featureOfInterest\" sent with invalid value: %s - available options: %s"%(filter.featureOfInterest,fl))
        
        if filter.observedProperty:
            opl = BuildobservedPropertyList(pgdb, filter.offering)
            for op in filter.observedProperty:
                if not op in opl:
                    raise sosException.SOSException(2,"Parameter \"observedProperty\" sent with invalid value: %s - available options: %s"%(filter.observedProperty,opl))
        
        #SET TIME PERIOD
        #=========================================
        tp=[]
        if filter.eventTime == None:
            tp = [None,None]
        else:
            for t in filter.eventTime:
                if len(t) == 2:
                    tp.append(iso.parse_datetime(t[0]))
                    tp.append(iso.parse_datetime(t[1]))
                if len(t)==1:
                    tp.append(iso.parse_datetime(t[0]))
        #else: rise error ???
        self.period = [min(tp),max(tp)]
        
        self.obs=[]
        
        #BUILD PROCEDURES LIST
        #=========================================
        #---select part of query
        sqlSel = "SELECT DISTINCT"
        sqlSel += " id_prc, name_prc, name_oty, stime_prc, etime_prc, time_res_prc, name_tru"
        #---from part of query
        sqlFrom = "FROM %s.procedures, %s.proc_obs p, %s.observed_properties, %s.uoms, %s.time_res_unit," %(sosConfig.schema,sosConfig.schema,sosConfig.schema,sosConfig.schema,sosConfig.schema)
        sqlFrom += " %s.off_proc o, %s.offerings, %s.obs_type" %(sosConfig.schema,sosConfig.schema,sosConfig.schema)
        if filter.featureOfInterest:
            sqlFrom += " ,%s.foi, %s.feature_type" %(sosConfig.schema,sosConfig.schema)
        
        sqlWhere = "WHERE id_prc=p.id_prc_fk AND id_opr_fk=id_opr AND o.id_prc_fk=id_prc AND id_off_fk=id_off AND id_uom=id_uom_fk AND id_tru=id_tru_fk AND id_oty=id_oty_fk"
        sqlWhere += " AND name_off='%s'" %(filter.offering)
        
        #---where condition based on offering
        
        if filter.featureOfInterest:
            sqlWhere += " AND id_foi=id_foi_fk AND id_fty=id_fty_fk AND (name_foi='%s')" %(filter.featureOfInterest)
        
        #---where condition based on procedures
        if filter.procedure:
            sqlWhere += " AND ("
            procWhere = []
            for proc in filter.procedure:
                procWhere.append("name_prc='%s'" %(proc))
            sqlWhere += " OR ".join(procWhere)
            sqlWhere += ")"
        
        #---where condition based on observed properties
        sqlWhere += " AND ("
        obsprWhere = []
        for obs in filter.observedProperty:
            obsprWhere.append("name_opr='%s' " %(obs)) 
        sqlWhere += " OR ".join(obsprWhere)
        sqlWhere += ")"
        
        #---where condition based on feature of interest
        #if many foi are allowed
        #if filter.seatureOdInterest:
        #    sqlWhere += " AND ("
        #    foiWhere = []
        #    for ffoi in filter.seatureOdInterest:
        #        foiWhere.append("name_foi='%s' " %(filter.featureOfInterest))
        #    sqlWhere += "AND".join(foiWhere) 
        #    sqlWhere += ")" 
        #######################################
        #raise sosException.SOSException(3,"SQL: %s"%(sql))
        #######################################
       
        try:
            res = pgdb.select(sqlSel + " " + sqlFrom + " " + sqlWhere)
        except:
            raise sosException.SOSException(3,"SQL: %s"%(sqlSel + " " + sqlFrom + " " + sqlWhere))
        
        #BUILD BASE INFOS FOR EACH PROCEDURE (Pi)
        #=========================================
        for o in res:
            #id_prc, name_prc, name_oty, stime_prc, etime_prc, time_res_prc, name_tru
            ob = observation()
            ob.id_prc=o["id_prc"]
            ob.procedure = sosConfig.urn["procedure"] + self.offInfo.name + ":" + o["name_prc"]
            
            #GET PROCEDURE TYPE OF Pi
            if o["name_oty"].lower() in ["fixpoint","mobilepoint"]:
                ob.procedureType=o["name_oty"]
                #TO BE IMPLEMENTED FOR MORE OPTIONS
            else:
                raise sosException.SOSException(2,"error in procedure type setting")
            
            ob.timeResVal = o["time_res_prc"]        
            ob.timeResUnit = o["name_tru"]
            
            #ob.observedProperty = o["name_opr"]
            #ob.opr_urn = sosConfig.urn["phenomena"] + o["name_opr"]
            #ob.uom = o["name_uom"]
            
            #GET FOI OF Pi
            sqlFoi  = "SELECT name_fty, name_foi, ST_AsGml(ST_Transform(geom_foi,%s)) as gml" %(filter.srsName)
            sqlFoi += " FROM %s.procedures, %s.foi, %s.feature_type" %(sosConfig.schema,sosConfig.schema,sosConfig.schema)
            sqlFoi += " WHERE id_foi_fk=id_foi AND id_fty_fk=id_fty AND id_prc=%s" %(o["id_prc"])
            ############################################
            #raise sosException.SOSException(3,"SQL: %s"%(sqlFoi))
            ############################################
            try:
                resFoi = pgdb.select(sqlFoi)
            except:
                raise sosException.SOSException(3,"SQL: %s"%(sql))

            ob.featureOfInterest = resFoi[0]["name_foi"]
            ob.foi_urn = sosConfig.urn["feature"] + resFoi[0]["name_fty"] + ":" + resFoi[0]["name_foi"]
            ob.foiGml = resFoi[0]["gml"]
            
            ob.dataType = sosConfig.urn["dataType"] + "timeSeries"
            ob.timedef = sosConfig.urn["parameter"] + "time:iso8601"
            ob.qualitydef = None #sosConfig.urn["parameter"] + "qualityIndex"
            
            #GET DATA FROM Pi ACCORDING TO THE FILTERS
            #=========================================

            sqlObsPro = "SELECT id_opr, name_opr, name_uom FROM %s.observed_properties, %s.proc_obs, %s.uoms" %(sosConfig.schema,sosConfig.schema,sosConfig.schema)
            sqlObsPro += " WHERE id_opr_fk=id_opr AND id_uom_fk=id_uom AND id_prc_fk=%s" %(o["id_prc"])
            sqlObsPro += " AND ("
            sqlObsPro += " OR ".join(["name_opr='" + str(i) + "'" for i in filter.observedProperty])
            sqlObsPro += " )"
            try:
                obspr_res = pgdb.select(sqlObsPro)
            except:
                raise sosException.SOSException(3,"SQL: %s"%(sqlObsPro))

            ob.observedProperty = []
            ob.opr_urn = []
            ob.uom = []
            for row in obspr_res:
                ob.observedProperty += [str(row["name_opr"])]
                ob.opr_urn += [str(sosConfig.urn["property"] + row["name_opr"])]
                ob.uom += [str(row["name_uom"])]
            #raise sosException.SOSException(3,"SQL: %s\n %s  / %s / %s"%(sqlObsPro, ob.observedProperty, ob.opr_urn, ob.uom))
            ''' Tre cicli invece di uno solo !!
            ob.observedProperty = [row["name_opr"] for row in obspr_res]
            ob.opr_urn = [(sosConfig.urn["property"] + row["name_opr"]) for row in obspr_res]
            ob.uom = [row["name_uom"] for row in obspr_res]
            '''
            
            #raise sosException.SOSException(3,"SQL: %s - %s - %s"%(ob.observedProperty,ob.opr_urn,ob.uom))
            
            sqlSel = "SELECT et.time_eti as t," 
            joinar=[]
            cols=[]
            valeFieldName = []
            for idx, obspr_row in enumerate(obspr_res):
                cols.append("C%s.val_msr as c%s_v" %(idx,idx))
                valeFieldName.append("c%s_v" %(idx))
                
                join_txt  = " left join ("
                join_txt += " SELECT distinct A%s.id_msr, A%s.val_msr, A%s.id_eti_fk" %(idx,idx,idx)
                join_txt += "   FROM %s.measures A%s, %s.event_time B%s" %(sosConfig.schema,idx,sosConfig.schema,idx)
                join_txt += " WHERE A%s.id_eti_fk = B%s.id_eti" %(idx,idx)
                join_txt += " AND A%s.id_opr_fk=%s" %(idx,obspr_row["id_opr"])
                join_txt += " AND B%s.id_prc_fk=%s" %(idx,o["id_prc"])
                
                if filter.eventTime:
                    join_txt += " AND ("
                    etf=[]
                    for ft in filter.eventTime:
                        if len(ft)==2:
                            etf.append("B%s.time_eti > timestamptz '%s' AND B%s.time_eti <= timestamptz '%s' " %(idx,ft[0],idx,ft[1]))
                        elif len(ft)==1:
                            etf.append("B%s.time_eti = timestamptz '%s' " %(idx,ft[0]))                        
                        else:
                            raise sosException.SOSException(2,"error in time filter")
                    join_txt += " OR ".join(etf)
                    join_txt +=  ")"
                else:
                    join_txt += " AND B%s.time_eti = (SELECT max(time_eti) FROM %s.event_time WHERE id_prc_fk=%s) " %(idx,sosConfig.schema,o["id_prc"])

                
                join_txt += " ) as C%s" %(idx)
                join_txt += " on C%s.id_eti_fk = et.id_eti" %(idx)
                joinar.append(join_txt)
            
            if ob.procedureType=="mobilepoint":
                join_txt  = " left join ("
                join_txt += " SELECT distinct Ax.id_pos, X(ST_Transform(Ax.geom_pos,%s)) as x,Y(ST_Transform(Ax.geom_pos,%s)) as y,Z(ST_Transform(Ax.geom_pos,%s)) as z, Ax.id_eti_fk" %(filter.srsName,filter.srsName,filter.srsName)
                join_txt += "   FROM %s.positions Ax, %s.event_time Bx" %(sosConfig.schema,sosConfig.schema)
                join_txt += " WHERE Ax.id_eti_fk = Bx.id_eti"
                join_txt += " AND Bx.id_prc_fk=%s" %(o["id_prc"])
                
                if filter.eventTime:
                    join_txt += " AND ("
                    etf=[]
                    for ft in filter.eventTime:
                        if len(ft)==2:
                            etf.append("Bx.time_eti > timestamptz '%s' AND Bx.time_eti <= timestamptz '%s' " %(ft[0],ft[1]))
                        elif len(ft)==1:
                            etf.append("Bx.time_eti = timestamptz '%s' " %(ft[0]))                        
                        else:
                            raise sosException.SOSException(2,"error in time filter")
                    join_txt += " OR ".join(etf)
                    join_txt +=  ")"
                else:
                    join_txt += " AND Bx.time_eti = (SELECT max(time_eti) FROM %s.event_time WHERE id_prc_fk=%s) " %(sosConfig.schema,o["id_prc"])
                
                join_txt += " ) as Cx on Cx.id_eti_fk = et.id_eti"
                sqlSel += " Cx.x as x, Cx.y as y, Cx.z as z, "
                joinar.append(join_txt)
                
            sqlSel += ", ".join(cols)
            sqlSel += " FROM %s.event_time et" %(sosConfig.schema)

            sqlData = " ".join(joinar)
            sqlData += " WHERE et.id_prc_fk=%s" %(o["id_prc"])
            
            if filter.eventTime:
                sqlData += " AND ("
                etf=[]
                for ft in filter.eventTime:
                    if len(ft)==2:
                        etf.append("et.time_eti > timestamptz '%s' AND et.time_eti <= timestamptz '%s' " %(ft[0],ft[1]))
                    elif len(ft)==1:
                        etf.append("et.time_eti = timestamptz '%s' " %(ft[0]))                        
                    else:
                        raise sosException.SOSException(2,"error in time filter")
                sqlData += " OR ".join(etf)
                sqlData +=  ")"
            else:
                sqlData += " AND et.time_eti = (SELECT max(time_eti) FROM %s.event_time WHERE id_prc_fk=%s) " %(sosConfig.schema,o["id_prc"])

            sqlData += " ORDER by et.time_eti"
            try:
                data_res = pgdb.select(sqlSel+sqlData)
            except:
                raise sosException.SOSException(3,"SQL: %s"%(sqlSel+sqlData))
            #raise sosException.SOSException(3,"SQL: %s"%(sqlSel+sqlData))
            
            #calculate sampling time
            """
            if len(data_res)>1:
                minT = data_res[0]["t"]
                maxT = data_res[-1]["t"]
            elif len(data_res)==1:
                minT = data_res[0]["t"]
                maxT = data_res[0]["t"]
            elif len(data_res)<1:
                evt=";".join([';'.join(i) for i in filter.eventTime]).split(";")
                evt=[iso.parse_datetime(et) for et in evt]
                minT = min(evt)
                maxT = max(evt)
            ob.samplingTime=[minT,maxT]
            """

            #raise sosException.SOSException(3,"%s  - %s" % (o["stime_prc"],o["etime_prc"],))
            if o["stime_prc"]!=None and o["etime_prc"]!=None:
                ob.samplingTime=[o["stime_prc"],o["etime_prc"]]
            else:
                ob.samplingTime = None
            #raise sosException.SOSException(3,"%s" % ob.samplingTime)
            
            #ADD OBSERVATIONS
            
            #raise sosException.SOSException(3,"DATA = %s" %(data_res))
            
            
            for line in data_res:
                if ob.procedureType=="fixpoint":
                    data_array = [line["t"]]
                elif ob.procedureType=="mobilepoint":
                    data_array = [line["t"],line["x"],line["y"],line["z"]]
                data_array.extend([line[field] for field in valeFieldName])
                ob.data.append(data_array)
            
            self.obs.append(ob)

            #raise sosException.SOSException(3,"DATA = %s" %(ob.data))
            #------------------------------
            """ 
            elif ob.procedureType=="mobilepoint":
                for line in data_res:
                    ob.data.append([line["t"],line["x"],line["y"],line["z"],line["v"],line["q"]])
                    
            
            #raise sosException.SOSException(3,"DATA: %s"%(ob.data))
            #Other cases
            if ob.procedureType=="fixgrid":
                raise sosException.SOSException(3,"FIXED GRID OBSERVATION NOT SUPPORTED")
            if ob.procedureType=="mobgrid":
                raise sosException.SOSException(3,"MOBILE GRID OBSERVATION NOT SUPPORTED")
            """
            
