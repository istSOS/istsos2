# istSOS Istituto Scienze della Terra Sensor Observation Service
# Copyright (C) 2010 Massimiliano Cannata
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

import isodate as iso

def render(GO):
    r = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
 
    r += "<om:ObservationCollection\n"
    r += "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" \n"
    r += "xmlns:swe=\"http://www.opengis.net/swe/1.0.1\" \n"
    r += "xmlns:gml=\"http://www.opengis.net/gml\" \n"
    r += "xmlns:om=\"http://www.opengis.net/om/1.0\" \n"
    r += "xmlns:xlink=\"http://www.w3.org/1999/xlink\" \n"
    r += "xmlns:sa=\"http://www.opengis.net/sampling/1.0\" \n" 
    r += "xsi:schemaLocation=\"http://www.opengis.net/om/1.0 http://www.opengis.net/sampling/1.0 http://schemas.opengis.net/om/1.0.0/om.xsd\"> \n"

    r += "<gml:name>" + GO.offInfo.name + "</gml:name>\n"
    r += "<gml:description>" + GO.offInfo.desc + "</gml:description>\n"
    
    for ob in GO.obs:
    
        #OBSERVATION OBJ
        r += "<om:member>\n"
        r += "  <om:Observation>\n"
        r += "    <om:procedure xlink:href=\"" + ob.procedure + "\"/>\n"
    
        #PERIODO DI CAMPIONAMENTO DEI DATI ESTRATTI      
        if ob.samplingTime != None:
            r += "    <sa:samplingTime>\n"
            r += "      <gml:TimePeriod>\n"
            r += "        <gml:beginPosition>" + iso.datetime_isoformat(ob.samplingTime[0]) + "</gml:beginPosition>\n"
            if ob.samplingTime[1]:
                r += "        <gml:endPosition>" + iso.datetime_isoformat(ob.samplingTime[1]) + "</gml:endPosition>\n"
            else:
                r += "        <gml:endPosition>" + iso.datetime_isoformat(ob.samplingTime[0]) + "</gml:endPosition>\n"
            r += "        <gml:TimeLength>\n"
            if ob.samplingTime[1]:
                r += "          <gml:duration>"  + iso.duration_isoformat(ob.samplingTime[1]-ob.samplingTime[0]) + "</gml:duration>\n"
            #r += "          <gml:timeInterval unit=\"" + str(ob.timeResUnit) + "\" radix=\"" + str(ob.timeResVal) + "\" factor=\"1\" />\n"
            r += "          <gml:timeInterval unit=\"" + str(ob.timeResUnit) + "\">" + str(ob.timeResVal) + "</gml:timeInterval>\n"            
            r += "        </gml:TimeLength>\n"
            r += "      </gml:TimePeriod>\n"
            r += "    </sa:samplingTime>\n"
        else:
            r += "    <sa:samplingTime/>\n"

    
        #PROPRIETA OSSERVATA
        if ob.procedureType == "fixpoint":
            ii=1
        elif ob.procedureType == "mobilepoint":
            ii=4
            
        r += "    <om:observedProperty>\n"
        r += "      <swe:CompositPhenomenon id=\"comp_" + str(ob.id_prc) + "\" dimension=\"" + str(len(ob.opr_urn)+ii) + "\">\n"
        if ob.procedureType == "fixpoint":
            r += "        <swe:component xlink:href=\"" + ob.timedef + " \" />"
            
        if ob.procedureType=="mobilepoint":
            r += "        <swe:component xlink:href=\"" + ob.timedef + " \" />"            
            r += "        <swe:component xlink:href=\"" + GO.refsys + ":x-position\" />"
            r += "        <swe:component xlink:href=\"" + GO.refsys + ":y-position\" />"
            r += "        <swe:component xlink:href=\"" + GO.refsys + ":z-position\" />"

        for urn in ob.opr_urn:    
            r += "        <swe:component xlink:href=\"" + urn + " \" />"
        r += "      </swe:CompositPhenomenon>\n"
        r += "    </om:observedProperty>\n"      
    
        #FEATURE OF INTEREST
        r += "    <om:featureOfInterest xlink:href=\"" + ob.foi_urn + "\">\n"
        r += ob.foiGml
        r += "    </om:featureOfInterest>"
    
        #SERIE TEMPORALE
        r += "    <om:result>\n"
        
        ii = 1
        if ob.procedureType=="mobilepoint":
            ii = 4
        
        #DESCRIZIONE DEI DATI ESTRATTI: VARIA A SECONDA DEL TIPO DI PROCEDURA
        
        #-- CASO GENERALE
        r += "      <swe:DataArray>\n"
        r += "        <swe:elementCount>\n"
        r += "          <swe:Count>\n"
        r += "            <swe:value>" + str(len(ob.observedProperty)+ii) + "</swe:value>\n"
        r += "          </swe:Count>\n"
        r += "        </swe:elementCount>\n"
        r += "        <swe:elementType name=\"SimpleDataArray\" xlink:href=\"http://mmisw.org/ont/mmi/obs.owl/timeSeriesDataRecord\">\n"
        r += "          <swe:DataRecord definition=\"http://mmiws.org/ont/x/timeSeries\">\n"
        r += "            <swe:field name=\"Time\">\n"
        r += "              <swe:Time definition=\"" + ob.timedef + "\"/>\n"
        r += "            </swe:field>\n"
        
        if ob.procedureType=="mobilepoint":
            r += "            <swe:field name=\"x-position\">\n"
            r += "              <swe:Quantity definition=\"" + GO.refsys + ":x-position\"/>\n"
            r += "            </swe:field>\n"
            r += "            <swe:field name=\"y-position\">\n"
            r += "              <swe:Quantity definition=\"" + GO.refsys + ":y-position\"/>\n"
            r += "            </swe:field>\n"
            r += "            <swe:field name=\"z-position\">\n"
            r += "              <swe:Quantity definition=\"" + GO.refsys + ":z-position\"/>\n"
            r += "            </swe:field>\n"
        
        for idx in range(len(ob.observedProperty)):
            r += "            <swe:field name=\"" + ob.observedProperty[idx] + "\">\n"
            r += "              <swe:Quantity definition=\"" + ob.opr_urn[idx] + "\">\n"
            r += "                <swe:uom code=\"" + ob.uom[idx] + "\"/>\n"
            r += "              </swe:Quantity>\n"
            r += "            </swe:field>\n"
            
        r += "          </swe:DataRecord>\n"
        r += "        </swe:elementType>\n"
        r += "        <swe:encoding>\n"
        r += "          <swe:TextBlock tokenSeparator=\",\" blockSeparator=\"@\" decimalSeparator=\".\"/>\n"
        r += "        </swe:encoding>\n"
        if len(ob.data)>0:
            r += "        <swe:values>"
            data=[]
            for row in range(len(ob.data)):
                str_data=[iso.datetime_isoformat(ob.data[row][0])]
                for i in range(1,len(ob.data[0])):
                    str_data.append(str(ob.data[row][i]))
                data.append(",".join(str_data))
            r += "@".join(data)
            r += "        </swe:values>\n"
        else:
            r += "        <swe:values/>"
        r += "      </swe:DataArray>\n"
        r += "    </om:result>\n"
        r += "  </om:Observation>\n"
        r += "</om:member>\n"
    r += "</om:ObservationCollection>" 
    
    return r


