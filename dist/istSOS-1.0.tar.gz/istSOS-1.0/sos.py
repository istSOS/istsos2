import sys

from mod_python import util, apache, psp
import urllib
import cStringIO
import traceback
import decimal

import sosConfig
import istSOS
from istSOS import sosDatabase
from istSOS import sosException

class bufferProxy:
    # Adapted from
    # http://www.modpython.org/pipermail/mod_python/2004-November/016841.html
    # allows clearing output in case of error
    def __init__(self,outputBuffer):
        self.outputBuffer = outputBuffer
    def write(self,data,flush=None):
        self.outputBuffer.write(data)
        
def index(req):
    
    outputBuffer = cStringIO.StringIO()
    oldReqWrite = req.write

    try:
        #get form
        if not req.headers_in.has_key("content-type"):
            content_type = "application/x-www-form-urlencoded"
        else:
            content_type = req.headers_in["content-type"]
        #if content_type == "application/x-www-form-urlencoded" or content_type[:10] == "multipart/":
	    #    req.form = util.FieldStorage(req,keep_blank_values=True)        
        
        #form = req.form
        
        #raise sosException.SOSException(3,"qui ci arrivo: %s" %(form))
        #req.content_type = "text/xml"
        req.content_type = "text/plain"
        method=str(req.method)
        pgdb = sosDatabase.sosPgDB(sosConfig.connection["user"],
                               sosConfig.connection["password"],
                               sosConfig.connection["dbname"],
                               sosConfig.connection["host"],
                               sosConfig.connection["port"])
        
        from istSOS.filters import factory_filters as FF
        from istSOS.responders import factory_response as FR
        from istSOS.renderers import factory_render as FRe
        
        req_filter = FF.sosFactoryFilter(req)
        response = FR.sosFactoryResponse(req_filter,pgdb)
        render = FRe.sosFactoryRender(response)
        try:
    	    req.content_type = req_filter.responseFormat
        except:
	        pass
    	req.send_http_header()
    	
        return render
 
            

    except sosException.SOSException, e:
        outputBuffer.seek(0)
        outputBuffer.truncate(0)
        req.write = oldReqWrite
        return e.ToXML()
    
    except Exception, e:
        outputBuffer.seek(0)
        outputBuffer.truncate(0)
        req.write = oldReqWrite
        othertext = traceback.format_exception(*sys.exc_info())
        return "%s" % (sosException.SOSException(e.__class__.__name__, e, othertext),)
        
    return
    
